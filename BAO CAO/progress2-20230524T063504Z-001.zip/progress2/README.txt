2223-HK2-QT2-TTNT-en.pdf for groups N1, N2, and N3
2223-HK2-QT2-TTNT-vi.pdf for groups N4, N5, and N6