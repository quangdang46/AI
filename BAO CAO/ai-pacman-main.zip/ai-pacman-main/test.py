a=[1,2,3,4]
print(a.asList())