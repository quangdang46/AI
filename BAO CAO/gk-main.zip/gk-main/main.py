from pysat.solvers import Glucose3
from itertools import combinations
import itertools

class MatrixColoring:
    def __init__(self, n, m, nonogram):
        self.n = n
        self.m = m
        self.nonogram = nonogram

    def get_var_id(self, i, j):
        return i * self.m + j + 1

    def get_adjacent_variables(self, i, j):
        neighbors = []
        for x in range(i - 1, i + 2):
            for y in range(j - 1, j + 2):
                if x < 0 or x >= self.n or y < 0 or y >= self.m:
                    continue
                neighbors.append(self.get_var_id(x, y))
        return neighbors
    
    def generate_cnf_clauses(self):
        clauses = []
        for i in range(self.n):
            for j in range(self.m):
                var_id = self.get_var_id(i, j)
                clauses.append([var_id, -var_id])
                
                cell_value = self.nonogram[i][j]
                if isinstance(cell_value, int) and cell_value == 0:
                    neighbors = self.get_adjacent_variables(i, j)
                    for neighbor in neighbors:
                        clauses.append([-neighbor])
                
                if isinstance(cell_value, int) and cell_value > 0:
                    neighbors = self.get_adjacent_variables(i, j)
                    for combo in combinations(neighbors, cell_value):
                        combo_list = list(combo)
                        remaining_neighbors = [n for n in neighbors if n not in combo_list]
                        
                        for x in combo_list:
                            clauses.append(remaining_neighbors + [x])
                        
                        for y in remaining_neighbors:
                            temp = [-v for v in combo_list] + [-y]
                            clauses.append(temp)
        return clauses

    def solve(self):
        clauses = self.generate_cnf_clauses()
        g = Glucose3()

        # Thêm các mệnh đề CNF vào Glucose3
        for clause in clauses:
            g.add_clause(clause)

        # Giải quyết bài toán và trả về kết quả
        if g.solve():
            model = g.get_model()
            return [[True if model[i * self.m + j] > 0 else False for j in range(self.m)] for i in range(self.n)]
        else:
            return None

    @classmethod
    def from_file(cls, filename):
        with open(filename, 'r') as f:
            lines = f.readlines()
            m, n = map(int, lines[0].strip().split())
            nonogram = []
            for line in lines[1:]:
                row = [int(c) if c != '.' else c for c in line.strip().split()]
                nonogram.append(row)
        return cls(n, m, nonogram)
    

    def print_solution(self, solution):
        if solution:
            for x, row in enumerate(solution):
                for y, value in enumerate(row):
                    char = ' ' if self.nonogram[x][y] == '.' else str(self.nonogram[x][y])
                    color = '\033[42m' if value else '\033[41m'
                    reset = '\033[0m'
                    print(f"{color}{char}{reset}", end='')
                print()
        else:
            print("No solution found")

solver = MatrixColoring.from_file('input2.txt')
# solver = MatrixColoring.from_file('input.txt')
result = solver.solve()
if result:
    solver.print_solution(result)
